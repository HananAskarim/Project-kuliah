<?php
require "fungsi.php";
$warga = query("SELECT * FROM presensi");
?>

<html>
<head>
<title>Presensi</title>
</head>
<body>
<h1>Presensi Karyawan PT. Mandataris</h1>
<table border='1' cellpadding='10' cellspacing='0'>
<tr>
<th>No</th>
<th>Aksi</th>
<th>Nama</th>
<th>Waktu Presensi</th>
</tr>

<?php $i = 1; ?>
<?php foreach ($warga as $row): ?>

<tr>
<td><?= $i; ?></td>
<td><a href="ubah.php?id=<?= $row["id"];?>">Ubah</a> | 
	<a href="hapus.php?id=<?= $row["id"];?>" onclick="return confirm('Apakah anda ingin menghapus data ini?')">Hapus</a></td>
<td><?= $row["nama"]?></td>
<td><?= $row["timing"]?></td>
<>
</tr>

<?php $i++; ?>
<?php endforeach;?>

</table>


</br>
<a href='tambahp.php'>Presensi Automatis</a>
</br>
</body>
</html>