<?php

require "fungsi.php";

if(isset($_POST["submit"]))	{	
	//cek jika data berhasil ditambahkan
	if (tambah($_POST) > 0){
		echo "
		<script>
		alert('data berhasil ditambahkan');
		document.location.href = 'presensi.php';
		</script>
		";
	}
	else{
		echo "
		<script>
		alert('data gagal ditambahkan');
		document.location.href = 'presensi.php';
		</script>
		";
	}
}
?>

<html>
<head>
<title>Absensi Automatic</title>
</head>
<body>
<h1>Auto Absensi</h1>
<form method='POST' action='' enctype='multipart/form-data'>
<table>
<tr>
<td><label for='nama'>Nama :</label></td>
<td><input type='text' name='nama' id='nama' required/></td>
</tr>
<tr>
<td><label for='timing'>Waktu Presensi :</label></td>
<td><input type='time' name='timing' id='timing' /></td>
</tr>
</table>
<button type='submit' name='submit'>Submit</button>
</form>
</body>
</html>