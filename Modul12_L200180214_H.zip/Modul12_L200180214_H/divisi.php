<?php
require "fungsi.php";
$warga = query("SELECT * FROM divisi");
?>

<html>
<head>
<title>Divisi</title>
</head>
<body>
<h1>Divisi dan Fungsionaris PT. Mandataris</h1>
<table border='1' cellpadding='10' cellspacing='0'>
<tr>
<th>No</th>
<th>Aksi</th>
<th>Divisi</th>
<th>Arah Gerak</th>
<th>Nama Fungsionaris</th>
</tr>

<?php $i = 1; ?>
<?php foreach ($warga as $row): ?>

<tr>
<td><?= $i; ?></td>
<td><a href="ubah.php?id=<?= $row["id"];?>">Ubah</a> | 
	<a href="hapus.php?id=<?= $row["id"];?>" onclick="return confirm('Apakah anda ingin menghapus data ini?')">Hapus</a></td>
<td><?= $row["divisi"]?></td>
<td><?= $row["arah_gerak"]?></td>
<td><?= $row["namaFK"]?></td>
</tr>

<?php $i++; ?>
<?php endforeach;?>

</table>


</br>
<a href='tambahp.php'>Tambah Divisi dan Fungsionaris</a>
</br>
</body>
</html>