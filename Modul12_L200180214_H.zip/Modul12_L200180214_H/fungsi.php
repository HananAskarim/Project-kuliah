<?php
//koneksi ke database
$konek = mysqli_connect("localhost", "root", "", "biodata");

function query($query){
	global $konek;
	$result = mysqli_query($konek, $query);
	$rows = [];
	while ( $row=mysqli_fetch_assoc($result)){
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data){
	global $konek;
	//ambil semua data yang dikirimkan form
	$nama= htmlspecialchars($data["nama"]);
	$umur= htmlspecialchars($data["umur"]);
	$alamat= htmlspecialchars($data["alamat"]);
	
	//insert data kedalam database
	$queri="INSERT INTO bio VALUES 
			('', '$nama', '$umur', '$alamat')";
			
	mysqli_query($konek, $queri);
	
	return mysqli_affected_rows($konek);
}

function hapus($id){
	global $konek;
	mysqli_query($konek, "DELETE FROM bio WHERE id=$id");
	return mysqli_affected_rows($konek);
}

function edit($data){
	global $konek;
	//ambil semua data yang dikirimkan form
	$id=$data["id"];
	$nama= htmlspecialchars($data["nama"]);
	$umur= htmlspecialchars($data["umur"]);
	$alamat= htmlspecialchars($data["alamat"]);
	
	//update data kedalam database
	$querii="UPDATE bio SET nama='$nama', umur='$umur', alamat='$alamat' WHERE id=$id";
			
	mysqli_query($konek, $querii);
	
	return mysqli_affected_rows($konek);	
}
?>