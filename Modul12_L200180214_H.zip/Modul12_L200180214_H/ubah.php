<?php

require "fungsi.php";

$id = $_GET["id"];

$wrg = query("SELECT * FROM bio WHERE id=$id")[0];

if(isset($_POST["submit"]))	{	
	//cek jika data berhasil diedit
	if (edit($_POST) > 0){
		echo "
		<script>
		alert('data berhasil diedit');
		document.location.href = 'home.php';
		</script>
		";
	}
	else{
		echo "
		<script>
		alert('data gagal diedit');
		document.location.href = 'home.php';
		</script>
		";
	}
}
?>

<html>
<head>
<title>Edit Biodata Warga</title>
</head>
<body>
<h1>Edit Biodata Warga</h1>
<form method='POST' action='' enctype='multipart/form-data'>
<input type='hidden' name='id' value="<?= $wrg["id"]; ?>">
<table>
<tr>
<td><label for='nama'>Nama :</label></td>
<td><input type='text' name='nama' id='nama' required value="<?= $wrg["nama"]; ?>"/></td>
</tr>
<tr>
<td><label for='umur'>Umur :</label></td>
<td><input type='text' name='umur' id='umur' required value="<?= $wrg["umur"]; ?>"/></td>
</tr>
<tr>
<td><label for='alamat'>Alamat :</label></td>
<td><input type='text' name='alamat' id='alamat' required value="<?= $wrg["alamat"]; ?>"/></td>
</tr>
</table>
<button type='submit' name='submit'>Save Data</button>
</form>
</body>
</html>