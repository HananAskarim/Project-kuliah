<?php

require "fungsi.php";

if(isset($_POST["submit"]))	{	
	//cek jika data berhasil ditambahkan
	if (tambah($_POST) > 0){
		echo "
		<script>
		alert('data berhasil ditambahkan');
		document.location.href = 'divisi.php';
		</script>
		";
	}
	else{
		echo "
		<script>
		alert('data gagal ditambahkan');
		document.location.href = 'divisi.php';
		</script>
		";
	}
}
?>

<html>
<head>
<title>Divisi Add</title>
</head>
<body>
<h1>Tambah Divisi dan Fungsionaris</h1>
<form method='POST' action='' enctype='multipart/form-data'>
<table>
<tr>
<td><label for='nama'>Nama Divisi:</label></td>
<td><input type='text' name='nama' id='nama' required/></td>
</tr>
<tr>
<td><label for='arah_gerak'>Arah Gerak Divisi :</label></td>
<td><input type='text' name='arah_gerak' id='arah_gerak' /></td>
</tr>
</table>
<button type='submit' name='submit'>Submit</button>
</form>
</body>
</html>