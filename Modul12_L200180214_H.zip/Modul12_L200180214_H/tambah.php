<?php

require "fungsi.php";

if(isset($_POST["submit"]))	{	
	//cek jika data berhasil ditambahkan
	if (tambah($_POST) > 0){
		echo "
		<script>
		alert('data berhasil ditambahkan');
		document.location.href = 'home.php';
		</script>
		";
	}
	else{
		echo "
		<script>
		alert('data gagal ditambahkan');
		document.location.href = 'home.php';
		</script>
		";
	}
}
?>

<html>
<head>
<title>Tambah Data Warga</title>
</head>
<body>
<h1>Tambah Data Warga Baru</h1>
<form method='POST' action='' enctype='multipart/form-data'>
<table>
<tr>
<td><label for='nama'>Nama :</label></td>
<td><input type='text' name='nama' id='nama' required/></td>
</tr>
<tr>
<td><label for='umur'>Umur :</label></td>
<td><input type='text' name='umur' id='umur' required/></td>
</tr>
<tr>
<td><label for='alamat'>Alamat :</label></td>
<td><input type='text' name='alamat' id='alamat' required/></td>
</tr>
</table>
<button type='submit' name='submit'>Tambah Data</button>
</form>
</body>
</html>