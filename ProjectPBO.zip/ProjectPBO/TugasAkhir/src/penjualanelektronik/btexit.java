/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualanelektronik;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
/**
 *
 * @author Robby
 */
public class btexit extends JPanel {
    static int hitung = 0;
    class dep extends JPanel{
        protected final Image gambarPanel;
        public dep(){
        btexit.de b = new btexit.de();
        gambarPanel = new ImageIcon(getClass().getResource
        ("/img/icons8_close_window_30px.png")).getImage();
        }
    }
    public static class de{
        public de(){
            de.b();
        }
        static int b(){
            return hitung =+1;
        }
    }
}
